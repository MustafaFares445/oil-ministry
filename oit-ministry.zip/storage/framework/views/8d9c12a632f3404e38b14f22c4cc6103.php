<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">

            <div class="container_fluid_image_top_left"></div>
            <div class="container_fluid_image_bottom_left"></div>
            <div class="container_fluid_image_bottom_right"></div>
            <div class="container_fluid_image_top_right"></div>



                <!-- start section category -->
    
        <section class="">


            <a href="<?php echo e(route('affiliated-entities.create')); ?>"><button class="btn_show_product">Add Affiliated Entity</button></a>

            <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
              <table class="w-full text-sm text-left text-gray-500 dark:text-gray-400 dash_table">
                  <thead class="text-xs text-gray-700 uppercase  dark:bg-gray-700 dark:text-gray-400 table_color">
                      <tr>
                          <th scope="col" class="px-6 py-3"> # </th>
                          <th scope="col" class="px-6 py-3"> Affiliated Entity Name </th>
                          <th scope="col" class="px-6 py-3"> Image </th>
                      </tr>
                  </thead>
                  <tbody>


                    <?php $__currentLoopData = $affiliatedEntities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliatedEntity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b  dark:border-gray-700 table_color">
                        <th scope="row" class="px-6 py-4 table_padding whitespace-nowrap "><?php echo e($affiliatedEntity->id); ?></th>
                        <td class="px-6 py-4 table_padding"><?php echo e($affiliatedEntity->name); ?></td>
                        <td class="table_padding"><img  style="width: 80px; height: 80px;" src="<?php echo e(asset('images/' .$affiliatedEntity->img)); ?>">
                        </td>
                            <a href="<?php echo e(route('affiliated-entities.edit',$affiliatedEntity->id)); ?>" class="btn_update">Update</a>
                            <form action="<?php echo e(route('affiliated-entities.destroy',$affiliatedEntity->id)); ?>" method="POST">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button class="btn_delete" type="submit">Delete</button>
                            </form>

                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




                  </tbody>
              </table>
            </div>
        </section>
        
          <!-- end section category -->




        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\oit-ministry\resources\views/admin/pages/AffiliatedEntities/index.blade.php ENDPATH**/ ?>