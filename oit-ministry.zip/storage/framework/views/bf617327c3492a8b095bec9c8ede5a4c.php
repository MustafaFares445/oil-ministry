<footer class="footer">
    <div class="container-fluid">

        <p class="copyright pull-left">
            Copyright &copy; 2022-2023 <a href="#" class="resturant_logo">Resturantly</a>. All rights reserved.
        </p>
    </div>
</footer>
<?php /**PATH C:\laragon\www\oit-ministry\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>