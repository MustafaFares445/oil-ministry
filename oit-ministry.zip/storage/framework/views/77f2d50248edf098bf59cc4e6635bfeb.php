





<div class="sidebar"  data-image="">






































































</div>

<div class="main-panel">
    <nav class="navbar navbar-default navbar-fixed">
        <div class="container-fluid">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navigation-example-2">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" style="
                color: black" href="#">Dashboard</a>
            </div>
            <div class="collapse navbar-collapse">
                <ul class="nav navbar-nav navbar-left">

                </ul>

                <ul class="nav navbar-nav navbar-right dashboard_color">

                    <li class="dropdown dashboard_color">
                          <a href="#" class="dropdown-toggle dashboard_color"  data-toggle="dropdown">
                                <p class="dashboard_color">
                                    Admin Name
                                    <b class="caret dashboard_color"></b>
                                </p>

                          </a>
                          <ul class="dropdown-menu">
                            <li>
                                <a href="#" class="log_out_dropdown">
                                    <i class="pe-7s-power"></i>
                                    <p>Log out</p>
                                </a>
                            </li>

                          </ul>
                    </li>

                    <li class="separator hidden-lg"></li>
                </ul>
            </div>
        </div>
    </nav>







<?php /**PATH C:\laragon\www\oit-ministry\resources\views/admin/layouts/header.blade.php ENDPATH**/ ?>